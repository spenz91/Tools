Alarm resetter GUI for IWMAC v1.4
---------------------------------
Bugs, questions: lars.gardegard@iwmac.se


A script for getting the active alarms on a plant (locally) and giving the user the option to reset them.


USAGE: 

1. Double-click the .exe-file and enter the standard password.

2. Choose which alarms to reset.

3. Restart plant server(?)

Done!



TECHNICAL INFORMATION/EXPLANATION:

The script gets active alarms using the following SQL:

--------------------------------
"SELECT pri, alarm_date, unit_id, driver_id, message FROM iw_res_alarm_status WHERE (value ='1' OR value='2' OR value='3') ORDER BY alarm_date DESC"
--------------------------------

When the user has chosen which ones to reset the script iterates over the alarms and for the ones that are checked it runs this:

--------------------------------
cmd /k C:\iwmac\plant_server3\tools\reset_alarm.bat [DRIVER_ID FOR THE CHOSEN ALARM]
--------------------------------